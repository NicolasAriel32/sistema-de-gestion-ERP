import { Button } from '@/components/ui/button';

const modulos = [
  { fase: 'FASE 0', nombre: 'Fundaciones', detalle: 'Esquema, RLS, numeración, seed', estado: 'listo' },
  { fase: 'FASE 1', nombre: 'Auth y catálogos', detalle: 'Login, empresas, 7 CRUD', estado: 'pendiente' },
  { fase: 'FASE 2', nombre: 'Ventas y facturación', detalle: 'Comprobantes, IVA, CAE, PDF', estado: 'pendiente' },
  { fase: 'FASE 3', nombre: 'Stock y compras', detalle: 'Kardex, transferencias, órdenes', estado: 'pendiente' },
  { fase: 'FASE 4', nombre: 'Tesorería', detalle: 'Cajas, cobros, cuentas corrientes', estado: 'pendiente' },
  { fase: 'FASE 5', nombre: 'Dashboard y reportes', detalle: 'IVA, ventas, stock valorizado', estado: 'pendiente' },
  { fase: 'FASE 6', nombre: 'Hardening', detalle: 'Auditoría, tests, webhooks, deploy', estado: 'pendiente' },
] as const;

export default function Home() {
  return (
    <main className="mx-auto flex min-h-screen max-w-3xl flex-col justify-center px-6 py-16">
      <header className="border-b border-border pb-6">
        <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">
          Sistema de gestión comercial
        </p>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight">GestiónPyme</h1>
        <p className="mt-2 max-w-xl text-muted-foreground">
          Multi-empresa, multi-depósito y facturación electrónica para PyMEs argentinas.
        </p>
      </header>

      <section className="mt-8">
        <h2 className="mb-3 text-xs font-medium uppercase tracking-widest text-muted-foreground">
          Estado de construcción
        </h2>

        <table className="w-full border-collapse">
          <tbody>
            {modulos.map((modulo) => (
              <tr key={modulo.fase} className="border-b border-border last:border-0">
                <td className="cod py-2 pr-4 align-top text-xs text-muted-foreground">
                  {modulo.fase}
                </td>
                <td className="py-2 pr-4 align-top font-medium">{modulo.nombre}</td>
                <td className="py-2 pr-4 align-top text-muted-foreground">{modulo.detalle}</td>
                <td className="py-2 text-right align-top">
                  {modulo.estado === 'listo' ? (
                    <span className="text-xs font-medium text-[var(--success)]">listo</span>
                  ) : (
                    <span className="text-xs text-muted-foreground">pendiente</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <footer className="mt-8 flex items-center gap-3 border-t border-border pt-6">
        <Button disabled>Ingresar</Button>
        <span className="text-xs text-muted-foreground">
          El acceso se habilita en la FASE 1.
        </span>
      </footer>
    </main>
  );
}
